
<template>
<body>
<div class="container">
  <h2 class="text-center mt-10">My Todo List App</h2>

  <!-- untuk inputannya -->
  <div class="d-flex mt-5">
    <input v-model="task" type="text" placeholder ="fill here" class="form-control mt-3">
    <button @click="addTodo" class="btn btn-warning mt-3">Submit</button>
     </div>

    <table class="list-group mt-5">
  <thead>
    <tr class="list-group">
      <th scope="col">Task</th>
    </tr>
    <td></td>
  </thead>
  <tbody class="list">
    <tr v-for="(tasks, index) in tasks" :key="index" class="list-group-item">
    <input type="checkbox">
    <label for="checkbox"> {{tasks.name}}</label>
   
      <td>
        <div>
           <button type="button" class="btn btn-outline-danger mt-3" @click="deleteTodo(index)">Delete</button>
        </div>
      
    </td>
    </tr>
  </tbody>
</table>
</div>
</body>

</template>]

<script>
export default {
  name: 'todo-list',
  data(){
    return {
      task: '',
      editTask: null,
      tasks: [
        {
          name: 'Streaming Youtube',
          status: 'Todo'
        },
        {
          name: 'Marathon watching k-dramas',
          status: 'On going'
        },
        {
          name: 'Sleeping all day',
          status: 'Not yet'
        }
      ]
    }
  }, 
  methods: {
    addTodo(){
    if(this.task.length === 0) return;

    this.tasks.push({
      name: this.task
    })
    },
    deleteTodo(index){
    this.tasks.splice(index, 1);
    },
  
  }
}


</script>


<style>

.container {
  margin-top: 40px;
}

.d-flex input{
  margin-right: 11px;
}

.d-flex .btn{
  margin-right: 500px;
}

.list-group{
  margin-right: 500px;
}

.list .list-group-item input{
  width: 15px;
  margin-right: 4px;
} 

.list .list-group-item input:hover{
  border-color: var(--checkbox-color);
} 

.list .list-group-item input:checked + label{
  text-decoration: line-through;

} 

</style>

 <!-- 
   Kak, maaf ya punya dyah kurang bagus todo listnya,
udah nyoba styiling tapi malah jadi jelek, jadi dyahnya balikin
ke bentuk semula T_T
  -->


